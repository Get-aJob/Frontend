import { create } from 'zustand';

interface MobilesidebarStore {
  isOpen: boolean;
  toggle: () => void;
  open: () => void;
}

export const useMobilesidebarStore = create<MobilesidebarStore>((set, get) => ({
  isOpen: false,
  toggle: () => {
    set({ isOpen: !get().isOpen });
  },
  open: () => {
    set({ isOpen: true });
  },
}));
